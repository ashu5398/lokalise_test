package com.example

import android.app.Application
import co.lokalise.android.sdk.LokaliseSDK

class MyApplication : Application() {


    override fun onCreate() {
        super.onCreate()

        LokaliseSDK.init("51c9fcfff973c4eed28ec9bb0e96e2fe6c7180b2", "286287475f68941b2aa9d8.28354534", this)

        LokaliseSDK.updateTranslations()
    }
}