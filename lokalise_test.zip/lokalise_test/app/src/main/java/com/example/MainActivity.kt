package com.example

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import co.lokalise.android.sdk.LokaliseSDK
import co.lokalise.android.sdk.core.LokaliseContextWrapper

class MainActivity : AppCompatActivity() {


    override fun attachBaseContext(newBase: Context?) {
        super.attachBaseContext(LokaliseContextWrapper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<TextView>(R.id.tv_test_text).text = getString(R.string.string_section_GOLD_LOAN_err_upi_app_not_found)
    }
}